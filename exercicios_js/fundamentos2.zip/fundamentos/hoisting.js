console.log('a= ',a)
var a = 10;
console.log('a= ', a)


function test (){
    console.log('b = ',b)
    var b = 2
    console.log('b= ', b)
}
test()

// ----------------------------------------- //

/*console.log('c = ', c)
c = 1
console.log('c = ', c)*/ 
