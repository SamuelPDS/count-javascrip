const a = 10
let b = 34
b+= a // b = a + b
console.log(b)

b-=a
console.log(b)

b*=a
console.log(b)

b/=a
console.log(b)

b%=2

console.log(b)