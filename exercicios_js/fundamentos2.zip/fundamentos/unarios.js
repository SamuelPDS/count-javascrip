 
--num1
console.log(num1)