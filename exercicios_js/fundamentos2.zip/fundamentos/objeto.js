const prod1 = {} //chave => cria o objeto. OBJETO: junção de chave e valor
prod1.nome = 'Celular_Top_de_Linha'
prod1.preco = 4999,99
prod1['Desconto'] = 500.00

console.log(prod1)

const prod2 = {
    nome: 'Camisa polo', 
    preco: 79.9
}

console.log(prod2)

const prod3 = {
    nome: 'Lenovo 3i',
    preco: 3198.98,
    data: '02/03/2019'
}

console.log(prod3)

