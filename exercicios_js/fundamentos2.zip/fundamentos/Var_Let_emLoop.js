 for(var i = 0; i<=20; i++){
    console.log(i)
 }

 console.log('i =', i)

 for(let a = 0; a<100; a++){
   console.log(a)
 }
// console.log(a)