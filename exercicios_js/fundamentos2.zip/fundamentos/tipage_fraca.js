let a = 'qualquer'
console.log(a)
console.log(typeof a)

let b = 300
console.log(b)
console.log(typeof b)