var a = 20
let b = 30

console.log(a + b)