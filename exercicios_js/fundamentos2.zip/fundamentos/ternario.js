const resultado1 = nota1 => nota1>= 7 ? 'Aprovado': 'Reprovado'
const resultado2 = nota2 => nota2>= 7 ? 'Aprovado': 'Reprovado'

//console.log(resultado1(7.1))
console.log(`Você está ${resultado1(7.1)}!`)
console.log(`Você está ${resultado2(4)}!!`)