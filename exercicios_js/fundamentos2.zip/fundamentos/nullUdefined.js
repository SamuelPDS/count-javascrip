let valor
console.log(valor)

valor= null //ausencia de valor
console.log(valor)

const produto = {}
console.log(produto.preço)
//console.log(produto.preço.a) // Erro: procurar algo em um atributo não definido

produto.preco = null
console.log(produto)
//delete produto.preco
